package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.DeliverKillingBlow
import path.to.your.EmptyLeaf

/**
 * NOTES:
 * Check if mob requires killing blow.
 */
public class DoesRequireKillingBlow extends BranchTask {

    private DeliverKillingBlow deliverkillingblow = new DeliverKillingBlow();
    private EmptyLeaf emptyleaf = new EmptyLeaf();

    @Override
    public boolean validate() {
        return false;
    }

    @Override
    public TreeTask failureTask() {
        return emptyleaf;
    }

    @Override
    public TreeTask successTask() {
        return deliverkillingblow;
    }
}
