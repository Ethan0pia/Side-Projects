package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.DoesInventoryContainAnything
import path.to.your.OpenBank

/**
 * NOTES:
 * Checks if at bank. First deposit after getting a new task.
 */
public class IsBankOpenNewTask extends BranchTask {

    private DoesInventoryContainAnything doesinventorycontainanything = new DoesInventoryContainAnything();
    private OpenBank openbank = new OpenBank();

    @Override
    public boolean validate() {
        return false;
    }

    @Override
    public TreeTask failureTask() {
        return openbank;
    }

    @Override
    public TreeTask successTask() {
        return doesinventorycontainanything;
    }
}
