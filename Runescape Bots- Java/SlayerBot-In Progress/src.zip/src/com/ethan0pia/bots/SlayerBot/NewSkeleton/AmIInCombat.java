package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.IsMobHPLow
import path.to.your.AttackMob

/**
 * NOTES:
 * Checks if I am in combat.
 */
public class AmIInCombat extends BranchTask {

    private IsMobHPLow ismobhplow = new IsMobHPLow();
    private AttackMob attackmob = new AttackMob();

    @Override
    public boolean validate() {
        return false;
    }

    @Override
    public TreeTask failureTask() {
        return attackmob;
    }

    @Override
    public TreeTask successTask() {
        return ismobhplow;
    }
}
