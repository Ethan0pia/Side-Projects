package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.AreItemsOnGroundWorthX
import path.to.your.WalkMob

/**
 * NOTES:
 * Checks to see if we are at the monster
 */
public class AmIAtMob extends BranchTask {

    private AreItemsOnGroundWorthX areitemsongroundworthx = new AreItemsOnGroundWorthX();
    private WalkMob walkmob = new WalkMob();

    @Override
    public boolean validate() {
        return false;
    }

    @Override
    public TreeTask failureTask() {
        return walkmob;
    }

    @Override
    public TreeTask successTask() {
        return areitemsongroundworthx;
    }
}
