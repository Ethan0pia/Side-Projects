package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.DepositEverything
import path.to.your.SetBankBooleanTrue

/**
 * NOTES:
 * Checks if inventory is empty after banking for new task.
 */
public class DoesInventoryContainAnything extends BranchTask {

    private DepositEverything depositeverything = new DepositEverything();
    private SetBankBooleanTrue setbankbooleantrue = new SetBankBooleanTrue();

    @Override
    public boolean validate() {
        return false;
    }

    @Override
    public TreeTask failureTask() {
        return setbankbooleantrue;
    }

    @Override
    public TreeTask successTask() {
        return depositeverything;
    }
}
