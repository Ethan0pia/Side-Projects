package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.DoesBagHaveFood
import path.to.your.DoIHaveATask

/**
 * NOTES:
 * Checks player's Health, true if under X%
 */
public class CheckHealth extends BranchTask {

    private DoesBagHaveFood doesbaghavefood = new DoesBagHaveFood();
    private DoIHaveATask doihaveatask = new DoIHaveATask();

    @Override
    public boolean validate() {
        return false;
    }

    @Override
    public TreeTask failureTask() {
        return doihaveatask;
    }

    @Override
    public TreeTask successTask() {
        return doesbaghavefood;
    }
}
