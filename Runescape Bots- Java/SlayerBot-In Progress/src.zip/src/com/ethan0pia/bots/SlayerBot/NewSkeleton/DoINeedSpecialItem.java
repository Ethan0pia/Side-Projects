package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.DoesBankContainSpecialItem
import path.to.your.DoesInventoryContainRoK

/**
 * NOTES:
 * Checks to see if we need a special item for this monster. If we already have it, return false.
 */
public class DoINeedSpecialItem extends BranchTask {

    private DoesBankContainSpecialItem doesbankcontainspecialitem = new DoesBankContainSpecialItem();
    private DoesInventoryContainRoK doesinventorycontainrok = new DoesInventoryContainRoK();

    @Override
    public boolean validate() {
        return false;
    }

    @Override
    public TreeTask failureTask() {
        return doesinventorycontainrok;
    }

    @Override
    public TreeTask successTask() {
        return doesbankcontainspecialitem;
    }
}
