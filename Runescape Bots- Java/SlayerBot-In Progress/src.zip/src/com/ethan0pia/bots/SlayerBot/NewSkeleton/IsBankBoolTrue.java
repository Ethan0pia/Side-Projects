package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.AreWeGeared
import path.to.your.AmIAtTheBankNewTask

/**
 * NOTES:
 * Checks if player has banked since getting this task.
 */
public class IsBankBoolTrue extends BranchTask {

    private AreWeGeared arewegeared = new AreWeGeared();
    private AmIAtTheBankNewTask amiatthebanknewtask = new AmIAtTheBankNewTask();

    @Override
    public boolean validate() {
        return false;
    }

    @Override
    public TreeTask failureTask() {
        return amiatthebanknewtask;
    }

    @Override
    public TreeTask successTask() {
        return arewegeared;
    }
}
