package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.WalkBank
import path.to.your.WalkBank

/**
 * NOTES:
 * Checks if player has a ring of kinship in inventory or equipped.
 */
public class DoesPlayerHaveRoK extends BranchTask {

    private WalkBank walkbank = new WalkBank();
    private WalkBank walkbank = new WalkBank();

    @Override
    public boolean validate() {
        return false;
    }

    @Override
    public TreeTask failureTask() {
        return walkbank;
    }

    @Override
    public TreeTask successTask() {
        return walkbank;
    }
}
