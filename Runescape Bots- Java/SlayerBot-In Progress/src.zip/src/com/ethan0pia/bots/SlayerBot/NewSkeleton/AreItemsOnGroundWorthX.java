package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.IsInventoryFullOrContainsStackableAlready
import path.to.your.AmIInCombat

/**
 * NOTES:
 * Are items on the ground worth X or are noteable/stackable
 */
public class AreItemsOnGroundWorthX extends BranchTask {

    private IsInventoryFullOrContainsStackableAlready isinventoryfullorcontainsstackablealready = new IsInventoryFullOrContainsStackableAlready();
    private AmIInCombat amiincombat = new AmIInCombat();

    @Override
    public boolean validate() {
        return false;
    }

    @Override
    public TreeTask failureTask() {
        return amiincombat;
    }

    @Override
    public TreeTask successTask() {
        return isinventoryfullorcontainsstackablealready;
    }
}
