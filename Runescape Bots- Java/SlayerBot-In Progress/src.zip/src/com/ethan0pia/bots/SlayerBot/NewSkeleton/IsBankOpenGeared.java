package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.CloseBank
import path.to.your.WalkMob

/**
 * NOTES:
 * Is the bank open?
 */
public class IsBankOpenGeared extends BranchTask {

    private CloseBank closebank = new CloseBank();
    private WalkMob walkmob = new WalkMob();

    @Override
    public boolean validate() {
        return false;
    }

    @Override
    public TreeTask failureTask() {
        return walkmob;
    }

    @Override
    public TreeTask successTask() {
        return closebank;
    }
}
