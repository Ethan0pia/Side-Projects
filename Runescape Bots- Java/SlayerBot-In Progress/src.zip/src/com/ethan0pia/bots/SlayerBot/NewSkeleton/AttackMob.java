package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.LeafTask;

/**
 * NOTES:
 * Attack the monster.
 */
public class AttackMob extends LeafTask {

    @Override
    public void execute() {

    }
}
