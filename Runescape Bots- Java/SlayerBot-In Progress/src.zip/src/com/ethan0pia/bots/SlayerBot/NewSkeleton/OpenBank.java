package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.LeafTask;

/**
 * NOTES:
 * 
 */
public class OpenBank extends LeafTask {

    @Override
    public void execute() {

    }
}
