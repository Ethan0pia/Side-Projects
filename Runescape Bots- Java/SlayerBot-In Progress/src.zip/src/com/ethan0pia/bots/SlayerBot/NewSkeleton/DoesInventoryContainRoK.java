package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.DoesInventoryContainFood
import path.to.your.WithdrawRoK

/**
 * NOTES:
 * Checks to see if we have a ring of kinship equipped or in inventory
 */
public class DoesInventoryContainRoK extends BranchTask {

    private DoesInventoryContainFood doesinventorycontainfood = new DoesInventoryContainFood();
    private WithdrawRoK withdrawrok = new WithdrawRoK();

    @Override
    public boolean validate() {
        return false;
    }

    @Override
    public TreeTask failureTask() {
        return withdrawrok;
    }

    @Override
    public TreeTask successTask() {
        return doesinventorycontainfood;
    }
}
