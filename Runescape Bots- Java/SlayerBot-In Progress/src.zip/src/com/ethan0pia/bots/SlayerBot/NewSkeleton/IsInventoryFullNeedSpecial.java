package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.DepositOneFood
import path.to.your.WithdrawSpecial

/**
 * NOTES:
 * Equip the special item.
 */
public class IsInventoryFullNeedSpecial extends BranchTask {

    private DepositOneFood depositonefood = new DepositOneFood();
    private WithdrawSpecial withdrawspecial = new WithdrawSpecial();

    @Override
    public boolean validate() {
        return false;
    }

    @Override
    public TreeTask failureTask() {
        return withdrawspecial;
    }

    @Override
    public TreeTask successTask() {
        return depositonefood;
    }
}
