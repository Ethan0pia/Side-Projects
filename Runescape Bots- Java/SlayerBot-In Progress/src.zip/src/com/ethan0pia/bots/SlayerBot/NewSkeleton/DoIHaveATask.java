package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.IsBankBoolTrue
import path.to.your.AmIAtMaster

/**
 * NOTES:
 * Checks if player has a task.
 */
public class DoIHaveATask extends BranchTask {

    private IsBankBoolTrue isbankbooltrue = new IsBankBoolTrue();
    private AmIAtMaster amiatmaster = new AmIAtMaster();

    @Override
    public boolean validate() {
        return false;
    }

    @Override
    public TreeTask failureTask() {
        return amiatmaster;
    }

    @Override
    public TreeTask successTask() {
        return isbankbooltrue;
    }
}
