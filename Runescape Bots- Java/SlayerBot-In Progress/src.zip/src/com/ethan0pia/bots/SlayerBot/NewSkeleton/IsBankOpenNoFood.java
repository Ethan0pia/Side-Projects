package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.WithdrawFood
import path.to.your.OpenBank

/**
 * NOTES:
 * Checks if the bank is open when player does not have food.
 */
public class IsBankOpenNoFood extends BranchTask {

    private WithdrawFood withdrawfood = new WithdrawFood();
    private OpenBank openbank = new OpenBank();

    @Override
    public boolean validate() {
        return false;
    }

    @Override
    public TreeTask failureTask() {
        return openbank;
    }

    @Override
    public TreeTask successTask() {
        return withdrawfood;
    }
}
