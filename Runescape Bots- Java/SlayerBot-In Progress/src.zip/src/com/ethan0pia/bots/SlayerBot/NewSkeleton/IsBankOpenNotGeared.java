package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.DoINeedSpecialItem
import path.to.your.OpenBank

/**
 * NOTES:
 * 
 */
public class IsBankOpenNotGeared extends BranchTask {

    private DoINeedSpecialItem doineedspecialitem = new DoINeedSpecialItem();
    private OpenBank openbank = new OpenBank();

    @Override
    public boolean validate() {
        return false;
    }

    @Override
    public TreeTask failureTask() {
        return openbank;
    }

    @Override
    public TreeTask successTask() {
        return doineedspecialitem;
    }
}
