package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.GetTask
import path.to.your.WalkMaster

/**
 * NOTES:
 * Check if at the slayer master
 */
public class AmIAtMaster extends BranchTask {

    private GetTask gettask = new GetTask();
    private WalkMaster walkmaster = new WalkMaster();

    @Override
    public boolean validate() {
        return false;
    }

    @Override
    public TreeTask failureTask() {
        return walkmaster;
    }

    @Override
    public TreeTask successTask() {
        return gettask;
    }
}
