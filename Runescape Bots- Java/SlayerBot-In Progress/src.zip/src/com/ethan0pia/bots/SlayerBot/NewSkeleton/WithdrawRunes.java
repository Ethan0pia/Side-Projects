package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.LeafTask;

/**
 * NOTES:
 * Withdraw some runes.
 */
public class WithdrawRunes extends LeafTask {

    @Override
    public void execute() {

    }
}
