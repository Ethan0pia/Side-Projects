package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.WithdrawRunes
import path.to.your.LoadPreset

/**
 * NOTES:
 * Checks if we need runes and if we have them in our bag.
 */
public class DoWeNeedAndHaveRunes extends BranchTask {

    private WithdrawRunes withdrawrunes = new WithdrawRunes();
    private LoadPreset loadpreset = new LoadPreset();

    @Override
    public boolean validate() {
        return false;
    }

    @Override
    public TreeTask failureTask() {
        return loadpreset;
    }

    @Override
    public TreeTask successTask() {
        return withdrawrunes;
    }
}
