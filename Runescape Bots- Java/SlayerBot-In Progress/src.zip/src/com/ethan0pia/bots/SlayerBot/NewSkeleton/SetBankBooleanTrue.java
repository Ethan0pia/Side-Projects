package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.LeafTask;

/**
 * NOTES:
 * Sets bank boolean to true to signify banked this run.
 */
public class SetBankBooleanTrue extends LeafTask {

    @Override
    public void execute() {

    }
}
