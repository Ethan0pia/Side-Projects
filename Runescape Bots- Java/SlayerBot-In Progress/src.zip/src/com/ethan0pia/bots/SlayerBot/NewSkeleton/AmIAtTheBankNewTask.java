package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.IsBankOpenNewTask
import path.to.your.WalkBank

/**
 * NOTES:
 * Checks if at bank. First deposit after getting a new task.
 */
public class AmIAtTheBankNewTask extends BranchTask {

    private IsBankOpenNewTask isbankopennewtask = new IsBankOpenNewTask();
    private WalkBank walkbank = new WalkBank();

    @Override
    public boolean validate() {
        return false;
    }

    @Override
    public TreeTask failureTask() {
        return walkbank;
    }

    @Override
    public TreeTask successTask() {
        return isbankopennewtask;
    }
}
