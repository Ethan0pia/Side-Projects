package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.DoesRequireKillingBlow
import path.to.your.EmptyLeaf

/**
 * NOTES:
 * Checks monster's HP
 */
public class IsMobHPLow extends BranchTask {

    private DoesRequireKillingBlow doesrequirekillingblow = new DoesRequireKillingBlow();
    private EmptyLeaf emptyleaf = new EmptyLeaf();

    @Override
    public boolean validate() {
        return false;
    }

    @Override
    public TreeTask failureTask() {
        return emptyleaf;
    }

    @Override
    public TreeTask successTask() {
        return doesrequirekillingblow;
    }
}
