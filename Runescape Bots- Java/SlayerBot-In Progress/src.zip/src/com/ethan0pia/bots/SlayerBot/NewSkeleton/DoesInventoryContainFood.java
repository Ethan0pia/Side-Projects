package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.DoWeNeedAndHaveRunes
import path.to.your.WithdrawFood

/**
 * NOTES:
 * DoWeHaveFood
 */
public class DoesInventoryContainFood extends BranchTask {

    private DoWeNeedAndHaveRunes doweneedandhaverunes = new DoWeNeedAndHaveRunes();
    private WithdrawFood withdrawfood = new WithdrawFood();

    @Override
    public boolean validate() {
        return false;
    }

    @Override
    public TreeTask failureTask() {
        return withdrawfood;
    }

    @Override
    public TreeTask successTask() {
        return doweneedandhaverunes;
    }
}
