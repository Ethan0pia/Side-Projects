package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.IsBankOpenNotGeared
import path.to.your.WalkBank

/**
 * NOTES:
 * Do we have food, special item, runes/arrows, and can combat stuff be used.
 */
public class AmIAtBankNotGeared extends BranchTask {

    private IsBankOpenNotGeared isbankopennotgeared = new IsBankOpenNotGeared();
    private WalkBank walkbank = new WalkBank();

    @Override
    public boolean validate() {
        return false;
    }

    @Override
    public TreeTask failureTask() {
        return walkbank;
    }

    @Override
    public TreeTask successTask() {
        return isbankopennotgeared;
    }
}
