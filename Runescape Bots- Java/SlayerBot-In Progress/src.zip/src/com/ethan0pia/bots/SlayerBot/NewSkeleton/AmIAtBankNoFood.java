package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.IsBankOpenNoFood
import path.to.your.DoesPlayerHaveRoK

/**
 * NOTES:
 * Checks if at the bank when player does not have food.
 */
public class AmIAtBankNoFood extends BranchTask {

    private IsBankOpenNoFood isbankopennofood = new IsBankOpenNoFood();
    private DoesPlayerHaveRoK doesplayerhaverok = new DoesPlayerHaveRoK();

    @Override
    public boolean validate() {
        return false;
    }

    @Override
    public TreeTask failureTask() {
        return doesplayerhaverok;
    }

    @Override
    public TreeTask successTask() {
        return isbankopennofood;
    }
}
