package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.EatFood
import path.to.your.LootItem

/**
 * NOTES:
 * Checks inventory to see if player has room for item. If they are full and have stackable item or if they have food to eat to make room.
 */
public class IsInventoryFullOrContainsStackableAlready extends BranchTask {

    private EatFood eatfood = new EatFood();
    private LootItem lootitem = new LootItem();

    @Override
    public boolean validate() {
        return false;
    }

    @Override
    public TreeTask failureTask() {
        return lootitem;
    }

    @Override
    public TreeTask successTask() {
        return eatfood;
    }
}
