package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.EquipSpecial
import path.to.your.IsInventoryFullNeedSpecial

/**
 * NOTES:
 * Checks if special item can be equipped.
 */
public class IsSpecialEquippable extends BranchTask {

    private EquipSpecial equipspecial = new EquipSpecial();
    private IsInventoryFullNeedSpecial isinventoryfullneedspecial = new IsInventoryFullNeedSpecial();

    @Override
    public boolean validate() {
        return false;
    }

    @Override
    public TreeTask failureTask() {
        return isinventoryfullneedspecial;
    }

    @Override
    public TreeTask successTask() {
        return equipspecial;
    }
}
