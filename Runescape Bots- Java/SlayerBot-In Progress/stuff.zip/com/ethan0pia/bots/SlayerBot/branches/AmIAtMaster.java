package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.GetTask
import path.to.your.WalkMaster

/**
 * NOTES:
 * Check if at the slayer master
 */
public class AmIAtMaster extends BranchTask {

    private GetTask gettask;
    private WalkMaster walkmaster;
    private GoodAssSlayerBot Bot;

    public AmIAtMaster(GoodAssSlayerBot bot){
        Bot=bot;
        gettask = new GetTask(bot);
        walkmaster = new WalkMaster(bot);
    }

    @Override
    public boolean validate() {
        Area slayerMasterArea= Bot.mobList.masters(Bot.master);

        return Bot.player !=null && slayerMasterArea!=null && slayerMasterArea.contains(Bot.player);
    }

    @Override
    public TreeTask failureTask() {
        return walkmaster;
    }

    @Override
    public TreeTask successTask() {
        return gettask;
    }
}
