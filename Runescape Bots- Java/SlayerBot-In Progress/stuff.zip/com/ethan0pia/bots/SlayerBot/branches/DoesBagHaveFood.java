package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.EatFood
import path.to.your.AmIAtBankNoFood

/**
 * NOTES:
 * Checks bag for food.
 */
public class DoesBagHaveFood extends BranchTask {

    private EatFood eatfood = new EatFood(bot);
    private AmIAtBankNoFood amiatbanknofood = new AmIAtBankNoFood(bot);
    private GoodAssSlayerBot Bot;

    public DoesBagHaveFood(GoodAssSlayerBot bot){
        Bot=bot;
        eatfood = new EatFood(bot);
        amiatbanknofood = new AmIAtBankNoFood(bot);
    }

    @Override
    public boolean validate() {
        return Inventory.contains(Bot.food);
    }

    @Override
    public TreeTask failureTask() {
        return amiatbanknofood;
    }

    @Override
    public TreeTask successTask() {
        return eatfood;
    }
}
