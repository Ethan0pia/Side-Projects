package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.DoWeNeedAndHaveRunes
import path.to.your.WithdrawFood

/**
 * NOTES:
 * DoWeHaveFood
 */
public class DoesInventoryContainFood extends BranchTask {

    private DoWeNeedAndHaveRunes doweneedandhaverunes;
    private WithdrawFood withdrawfood;
    private GoodAssSlayerBot Bot;

    public HaveFood(GoodAssSlayerBot bot){
        Bot=bot;
        doweneedandhaverunes = new DoWeNeedAndHaveRunes(bot);
        withdrawfood = new WithdrawFood(bot);
    }

    @Override
    public boolean validate() {
        return Inventory.contains(Bot.food);
    }


    @Override
    public TreeTask failureTask() {
        return withdrawfood;
    }

    @Override
    public TreeTask successTask() {
        return doweneedandhaverunes;
    }
}
