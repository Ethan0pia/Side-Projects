package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.CloseBank
import path.to.your.WalkMob

/**
 * NOTES:
 * Is the bank open?
 */
public class IsBankOpenGeared extends BranchTask {

    private CloseBank closebank = new CloseBank(bot);
    private WalkMob walkmob = new WalkMob(bot);
    private GoodAssSlayerBot Bot;

    public IsBankOpenGeared(GoodAssSlayerBot bot){
        Bot=bot;
        closebank = new CloseBank(bot);
        walkmob = new WalkMob(bot);
    }

    @Override
    public boolean validate() {
        return Bank.isOpen();
    }

    @Override
    public TreeTask failureTask() {
        return walkmob;
    }

    @Override
    public TreeTask successTask() {
        return closebank;
    }
}
