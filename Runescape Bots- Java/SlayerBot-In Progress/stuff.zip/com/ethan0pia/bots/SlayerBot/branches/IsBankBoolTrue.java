package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.AreWeGeared
import path.to.your.AmIAtBankNewTask

/**
 * NOTES:
 * Checks if player has banked since getting this task.
 */
public class IsBankBoolTrue extends BranchTask {

    private AreWeGeared arewegeared = new AreWeGeared();
    private AmIAtBankNewTask amiatbanknewtask = new AmIAtBankNewTask();

    @Override
    public boolean validate() {
        return false;
    }

    @Override
    public TreeTask failureTask() {
        return amiatbanknewtask;
    }

    @Override
    public TreeTask successTask() {
        return arewegeared;
    }
}
