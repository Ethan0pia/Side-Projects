package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.WalkBank
import path.to.your.StopBot

/**
 * NOTES:
 * Checks if player has a ring of kinship in inventory or equipped.
 */
public class DoesPlayerHaveRoK extends BranchTask {

    private WalkBank walkbank;
    private StopBot stopBot;
    private GoodAssSlayerBot Bot;

    public DoesPlayerHaveRoK(GoodAssSlayerBot bot){
        Bot=bot;
        walkbank = new WalkBank(bot);
        StopBot = new StopBot(bot);

    }

    @Override
    public boolean validate() {
        if (!Equipment.contains(15707) && !Inventory.contains(15707)) {
            System.out.println("Ring of kinship not found. XD");
            Bot.stop();
        }

        return Equipment.contains(15707) || Inventory.contains(15707);
    }

    @Override
    public TreeTask failureTask() {
        return walkbank;
    }

    @Override
    public TreeTask successTask() {
        return walkbank;
    }
}
