package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.DoesInventoryContainAnything
import path.to.your.OpenBank

/**
 * NOTES:
 * Checks if at bank. First deposit after getting a new task.
 */
public class IsBankOpenNewTask extends BranchTask {

    private DoesInventoryContainAnything doesinventorycontainanything;
    private OpenBank openbank;
    private GoodAssSlayerBot Bot;

    public IsBankOpenNewTask(GoodAssSlayerBot bot){
        Bot=bot;
        doesinventorycontainanything = new DoesInventoryContainAnything(bot);
        openbank = new OpenBank(bot);
    }

    @Override
    public boolean validate() {
        return Bank.isOpen();
    }

    @Override
    public TreeTask failureTask() {
        return openbank;
    }

    @Override
    public TreeTask successTask() {
        return doesinventorycontainanything;
    }
}
