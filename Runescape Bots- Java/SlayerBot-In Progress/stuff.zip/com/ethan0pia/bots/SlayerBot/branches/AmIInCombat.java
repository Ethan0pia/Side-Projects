package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.IsMobHPLow
import path.to.your.AttackMob

/**
 * NOTES:
 * Checks if I am in combat.
 */
public class AmIInCombat extends BranchTask {

    private IsMobHPLow ismobhplow;
    private AttackMob attackmob;
    private GoodAssSlayerBot Bot;

    public AmIInCombat(GoodAssSlayerBot bot){
        Bot=bot;
        attackmob = new AttackMob(bot);
        ismobhplow = new IsMobHPLow(bot);
    }

    @Override
    public boolean validate() {
        if(Bot.player!=null) {
            boolean state = false;
            try{
                state = Bot.player.getTarget()==null || Bot.player.getTarget().getHealthGauge()==null || Bot.player.getTarget().getHealthGauge().getPercent()<1;
            }catch(Exception e){
                System.out.println("Failed to check if in combat.");
            }
            return state;
        }
        return true;
    }

    @Override
    public TreeTask failureTask() {
        return attackmob;
    }

    @Override
    public TreeTask successTask() {
        return ismobhplow;
    }
}
