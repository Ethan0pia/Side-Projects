package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.DoesBankContainSpecialItem
import path.to.your.DoesInventoryContainRoK

/**
 * NOTES:
 * Checks to see if we need a special item for this monster. If we already have it, return false.
 */
public class DoINeedSpecialItem extends BranchTask {

    private DoesBankContainSpecialItem doesbankcontainspecialitem;
    private DoesInventoryContainRoK doesinventorycontainrok;
    private GoodAssSlayerBot Bot;

    public HasSpecialItem(GoodAssSlayerBot bot){
        Bot=bot;
        doesbankcontainspecialitem = new DoesBankContainSpecialItem(bot);
        doesinventorycontainrok = new DoesInventoryContainRoK(bot);
    }

    @Override
    public boolean validate() {

        int task = Varbits.load(7923).getValue();
        if(Bot.mobList.getSpecialItem(task)==null){
            return false;
        }
        else {
            String item = Bot.mobList.getSpecialItem(task);
            return (Bot.player != null && item != null && (Inventory.contains(item) || Equipment.contains(item)));
        }

    }

    @Override
    public TreeTask failureTask() {
        return doesinventorycontainrok;
    }

    @Override
    public TreeTask successTask() {
        return doesbankcontainspecialitem;
    }
}
