package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.IsBankOpenNotGeared
import path.to.your.WalkBank

/**
 * NOTES:
 * Do we have food, special item, runes/arrows, and can combat stuff be used.
 */
public class AmIAtBankNotGeared extends BranchTask {

    private IsBankOpenNotGeared isbankopennotgeared;
    private WalkBank walkbank;
    private GoodAssSlayerBot Bot;

    public AmIAtBankNotGeared(GoodAssSlayerBot bot){
        Bot=bot;
        isbankopennotgeared = new IsBankOpenNotGeared(bot);
        walkbank = new WalkBank(bot);
    }

    private Area bankArea = new Area.Rectangular( new Coordinate(2885,3538,0), new Coordinate(2893, 3534, 0));

    @Override
    public boolean validate() {

        return Bot.player !=null && bankArea.contains(Bot.player) || new Area.Circular(new Coordinate(3449, 3717, 0), 40).contains(Bot.player);
    }

    @Override
    public TreeTask failureTask() {
        return walkbank;
    }

    @Override
    public TreeTask successTask() {
        return isbankopennotgeared;
    }
}
