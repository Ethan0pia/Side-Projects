package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.AmIAtBankGeared
import path.to.your.AmIAtBankNotGeared

/**
 * NOTES:
 * Do we have food, special item, runes/arrows, and can combat stuff be used.
 */
public class AreWeGeared extends BranchTask {

    private AmIAtBankGeared amiatbankgeared = new AmIAtBankGeared();
    private AmIAtBankNotGeared amiatbanknotgeared = new AmIAtBankNotGeared();

    @Override
    public boolean validate() {
        return false;
    }

    @Override
    public TreeTask failureTask() {
        return amiatbanknotgeared;
    }

    @Override
    public TreeTask successTask() {
        return amiatbankgeared;
    }
}
