package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.WithdrawRunes
import path.to.your.LoadPreset

/**
 * NOTES:
 * Checks if we need runes and if we have them in our bag.
 */
public class DoWeNeedAndHaveRunes extends BranchTask {

    private WithdrawRunes withdrawrunes = new WithdrawRunes(bot);
    private LoadPreset loadpreset = new LoadPreset(bot);
    private GoodAssSlayerBot Bot;

    public DoesNeedRunes(GoodAssSlayerBot bot){
        Bot=bot;
        withdrawrunes = new WithdrawRunes(bot);
        loadpreset = new LoadPreset(bot);
    }

    @Override
    public boolean validate() {
        int task = Varbits.load(7923).getValue();
        int combat = Bot.mobList.getCombatType(task);
        Bank.contains("Air rune");
        switch(combat){
            case 3:
                if(!Bank.contains(556)&& !Inventory.contains(556)){
                    System.out.println("No air runes.");
                    Bot.stop();
                }
                if(!Inventory.contains(556)) {
                    return true;
                }
            case 4:
                if(!Bank.contains(556)&& !Inventory.contains(556)){
                    System.out.println("No air runes.");
                    Bot.stop();
                }
                if(!Inventory.contains(556)) {
                    return true;
                }
                //Bank.withdraw("Water rune", 1000);
                break;
            case 5:
                if(!Bank.contains(556)&& !Inventory.contains(556)){
                    System.out.println("No air runes.");
                    Bot.stop();
                }
                if(!Inventory.contains(556)) {
                    return true;
                }
                //Bank.withdraw("Earth rune", 1000);
                break;
            case 6:
                if(!Bank.contains(556)&& !Inventory.contains(556)){
                    System.out.println("No air runes.");
                    Bot.stop();
                }
                if(!Inventory.contains(556)) {
                    return true;
                }
                //Bank.withdraw("Fire rune", 1000);
                break;
        }
        return false;
    }

    @Override
    public TreeTask failureTask() {
        return loadpreset;
    }

    @Override
    public TreeTask successTask() {
        return withdrawrunes;
    }
}
