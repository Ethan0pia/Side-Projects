package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.DepositOneFood
import path.to.your.WithdrawSpecial

/**
 * NOTES:
 * Equip the special item.
 */
public class IsInventoryFullNeedSpecial extends BranchTask {

    private DepositOneFood depositonefood;
    private WithdrawSpecial withdrawspecial;
    private GoodAssSlayerBot Bot;

    public IsInventoryFullSpecialItemNotEquipable(GoodAssSlayerBot bot){
        Bot=bot;
        depositonefood = new DepositOneFood(bot);
        withdrawspecial = new WithdrawSpecial(bot);
    }

    @Override
    public boolean validate() {
        return Inventory.isFull();
    }

    @Override
    public TreeTask failureTask() {
        return withdrawspecial;
    }

    @Override
    public TreeTask successTask() {
        return depositonefood;
    }
}
