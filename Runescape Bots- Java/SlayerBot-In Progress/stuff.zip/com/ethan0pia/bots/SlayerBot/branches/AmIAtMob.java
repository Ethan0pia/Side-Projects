package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.AreItemsOnGroundWorthX
import path.to.your.WalkMob

/**
 * NOTES:
 * Checks to see if we are at the monster
 */
public class AmIAtMob extends BranchTask {

    private AreItemsOnGroundWorthX areitemsongroundworthx;
    private WalkMob walkmob;
    private GoodAssSlayerBot Bot;

    public AmIAtMob(GoodAssSlayerBot bot){
        Bot=bot;
        areitemsongroundworthx = new AreItemsOnGroundWorthX(bot);
        walkmob = new WalkMob(bot);
    }

    @Override
    public boolean validate() {
        int task = Varbits.load(7923).getValue();
        Area monsterArea = Bot.mobList.getMobArea(task);

        return monsterArea != null && Bot.player!=null && monsterArea.contains(Bot.player);
    }

    @Override
    public TreeTask failureTask() {
        return walkmob;
    }

    @Override
    public TreeTask successTask() {
        return areitemsongroundworthx;
    }
}
