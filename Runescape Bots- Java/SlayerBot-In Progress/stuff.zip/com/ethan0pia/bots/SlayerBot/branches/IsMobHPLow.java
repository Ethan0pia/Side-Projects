package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.DoesRequireKillingBlow
import path.to.your.EmptyLeaf

/**
 * NOTES:
 * Checks monster's HP
 */
public class IsMobHPLow extends BranchTask {

    private DoesRequireKillingBlow doesrequirekillingblow;
    private EmptyLeaf emptyleaf = new EmptyLeaf();
    private GoodAssSlayerBot Bot;

    public IsMobHPLow(GoodAssSlayerBot bot){
        Bot=bot;
        doesrequirekillingblow = new DoesRequireKillingBlow(Bot);
    }

    private KillingBlow killingblow;
    private EmptyLeaf empty = new EmptyLeaf();

    @Override
    public boolean validate() {

        return (Bot.player != null && Bot.player.getTarget()!=null && Bot.player.getTarget().getHealthGauge().getPercent()<10);

    }
    @Override
    public TreeTask failureTask() {
        return emptyleaf;
    }

    @Override
    public TreeTask successTask() {
        return doesrequirekillingblow;
    }
}
