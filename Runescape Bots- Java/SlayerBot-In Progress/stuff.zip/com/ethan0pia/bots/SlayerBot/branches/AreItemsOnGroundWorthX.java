package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.IsInventoryFullOrContainsStackableAlready
import path.to.your.AmIInCombat

/**
 * NOTES:
 * Are items on the ground worth X or are noteable/stackable
 */
public class AreItemsOnGroundWorthX extends BranchTask {

    private IsInventoryFullOrContainsStackableAlready isinventoryfullorcontainsstackablealready;
    private AmIInCombat amiincombat;


    public AreItemsOnGroundWorthX(GoodAssSlayerBot bot, CheckGround itemList){
        Bot=bot;
        this.itemList=itemList;
        isstackable = new IsStackable(Bot, this.itemList);
    }

    private IsInventoryFullLooting isinventoryfulllooting;
    private IsStackable isstackable;

    @Override
    public boolean validate() {
        if(Bot.player!=null) {
            List<GroundItem> list = GroundItems.newQuery().within(new Area.Circular(Bot.player.getPosition(), 12)).reachable().results().asList();
            if (itemList.list != null) {
                for (GroundItem i : itemList.list) {
                    if (i != null && i.getDefinition()!=null && i.getId()!=15412 && i.getId()!=526) {
                        int id;
                        if (i.getDefinition().isNoted()) {
                            id = i.getDefinition().getUnnotedId();
                        } else {
                            id = i.getId();
                        }
                        GrandExchange.Item item=null;
                        if (i.getId() != 617 && i.getId()!=995) {
                            item = GrandExchange.lookup(id);
                        }
                        if (ItemDefinition.get(id).isTradeable() && (item != null || i.getId() != 617 || i.getId()!=995)) {
                            int price = 1;//coins
                            if(Bot.stuff.containsKey(id)){
                                price=Bot.stuff.getOrDefault(id,0);
                            }else {
                                if (item != null) {
                                    price = item.getPrice();
                                    if(!Bot.stuff.containsKey(item.getId())) {
                                        Bot.stuff.put(id, price);
                                        if (i.getDefinition() != null && i.getDefinition().isNoted()) {
                                            Bot.stuff.put(i.getId(), price);
                                        }
                                    }
                                }
                            }
                            if (price * i.getQuantity() > Bot.minVal) {
                                isinventoryfullorcontainsstackablealready = new isinventoryfullorcontainsstackablealready(Bot, i);
                                return true;
                            }
                        }
                    }
                    if (i != null && i.getDefinition()!=null && i.getId()!=15412 && i.getId()!=526) {
                        if (i.getDefinition().isNoted() || i.getDefinition().stacks()) {
                            int id;
                            if (i.getDefinition().isNoted()) {
                                id = i.getDefinition().getUnnotedId();
                            } else {
                                id = i.getId();
                            }
                            GrandExchange.Item item=null;
                            if (i.getId()!=995) {
                                item = GrandExchange.lookup(id);
                            }
                            if (ItemDefinition.get(id).isTradeable() && (item != null || i.getId()!=995)) {
                                int price = 1;//coins
                                if(Bot.stuff.containsKey(id)){
                                    price=Bot.stuff.getOrDefault(id,0);
                                }else {
                                    if (item != null) {
                                        price = item.getPrice();
                                        if (!Bot.stuff.containsKey(item.getId())) {
                                            Bot.stuff.put(id, price);
                                            if (i.getDefinition() != null && i.getDefinition().isNoted()) {
                                                Bot.stuff.put(i.getId(), price);
                                            }
                                        }
                                    }
                                }
                                if (price * i.getQuantity() > 250) {
                                    isinventoryfullorcontainsstackablealready = new isinventoryfullorcontainsstackablealready(Bot, i);
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    @Override
    public TreeTask failureTask() {
        return amiincombat;
    }

    @Override
    public TreeTask successTask() {
        return isinventoryfullorcontainsstackablealready;
    }
}
