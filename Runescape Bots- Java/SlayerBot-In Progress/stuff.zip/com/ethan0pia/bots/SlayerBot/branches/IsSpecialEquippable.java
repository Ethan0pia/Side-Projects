package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.EquipSpecial
import path.to.your.IsInventoryFullNeedSpecial

/**
 * NOTES:
 * Checks if special item can be equipped.
 */
public class IsSpecialEquippable extends BranchTask {

    private EquipSpecial equipspecial;
    private IsInventoryFullNeedSpecial isinventoryfullneedspecial;
    private GoodAssSlayerBot Bot;

    public IsSpecialEquipable(GoodAssSlayerBot bot){
        Bot=bot;
        equipspecial = new EquipSpecial(bot);
        isinventoryfullneedspecial = new IsInventoryFullNeedSpecial(bot);
    }

    @Override
    public boolean validate() {
        int task = Varbits.load(7923).getValue();
        return Bank.getItems(Bot.mobList.getSpecialItem(task)).first().getDefinition().isEquipable();
    }

    @Override
    public TreeTask failureTask() {
        return isinventoryfullneedspecial;
    }

    @Override
    public TreeTask successTask() {
        return equipspecial;
    }
}
