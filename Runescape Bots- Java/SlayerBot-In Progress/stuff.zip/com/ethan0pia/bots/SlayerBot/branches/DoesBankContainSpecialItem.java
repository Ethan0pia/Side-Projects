package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.IsSpecialEquippable
import path.to.your.StopBot

/**
 * NOTES:
 * Checks bank for special item.
 */
public class DoesBankContainSpecialItem extends BranchTask {

    private IsSpecialEquippable isspecialequippable;
    private StopBot stopbot;
    private GoodAssSlayerBot Bot;

    public DoesBankContainSpecialItem(GoodAssSlayerBot bot){
        Bot=bot;
        isspecialequippable = new IsSpecialEquippable(bot);
        stopbot = new StopBot(Bot);

    }

    @Override
    public boolean validate() {
        int task = Varbits.load(7923).getValue();
        return Bank.contains(Bot.mobList.getSpecialItem(task));
    }

    @Override
    public boolean validate() {
        return false;
    }

    @Override
    public TreeTask failureTask() {
        return stopbot;
    }

    @Override
    public TreeTask successTask() {
        return isspecialequippable;
    }
}
