package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.DeliverKillingBlow
import path.to.your.EmptyLeaf

/**
 * NOTES:
 * Check if mob requires killing blow.
 */
public class DoesRequireKillingBlow extends BranchTask {

    private DeliverKillingBlow deliverkillingblow;
    private EmptyLeaf emptyleaf;
    private GoodAssSlayerBot Bot;

    public RequiresBlow(GoodAssSlayerBot bot){
        Bot=bot;
        mobhpcheck = new MobHPCheck(Bot);
        deliverkillingblow = new DeliverKillingBlow(bot);
        emptyleaf = new EmptyLeaf(bot);
    }

    @Override
    public boolean validate() {

        int task = Varbits.load(7923).getValue();

        return Bot.mobList.getFinishingBlowName(task)!=null;
    }

    @Override
    public TreeTask failureTask() {
        return emptyleaf;
    }

    @Override
    public TreeTask successTask() {
        return deliverkillingblow;
    }
}
