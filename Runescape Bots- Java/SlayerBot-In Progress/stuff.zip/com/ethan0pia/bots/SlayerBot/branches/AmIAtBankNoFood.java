package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.IsBankOpenNoFood
import path.to.your.DoesPlayerHaveRoK

/**
 * NOTES:
 * Checks if at the bank when player does not have food.
 */
public class AmIAtBankNoFood extends BranchTask {

    private IsBankOpenNoFood isbankopennofood;
    private DoesPlayerHaveRoK doesplayerhaverok;
    private GoodAssSlayerBot Bot;

    public AmIAtBankNoFood(GoodAssSlayerBot bot){
        Bot=bot;
        isbankopennofood = new IsBankOpenNoFood(bot);
        doesplayerhaverok = new DoesPlayerHaveRoK(bot);
    }

    private Area bankArea = new Area.Rectangular( new Coordinate(2885,3538,0), new Coordinate(2893, 3534, 0));

    @Override
    public boolean validate() {

        return Bot.player !=null && bankArea.contains(Bot.player) || new Area.Circular(new Coordinate(3449, 3717, 0), 40).contains(Bot.player);
    }


    @Override
    public TreeTask failureTask() {
        return doesplayerhaverok;
    }

    @Override
    public TreeTask successTask() {
        return isbankopennofood;
    }
}
