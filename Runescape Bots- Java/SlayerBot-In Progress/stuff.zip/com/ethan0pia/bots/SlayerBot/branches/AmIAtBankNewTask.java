package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.IsBankOpenNewTask
import path.to.your.WalkBank

/**
 * NOTES:
 * Checks if at bank. First deposit after getting a new task.
 */
public class AmIAtBankNewTask extends BranchTask {

    private IsBankOpenNewTask isbankopennewtask;
    private WalkBank walkbank;
    private GoodAssSlayerBot Bot;

    public AmIAtBankNewTask(GoodAssSlayerBot bot){
        Bot=bot;
        walkbank = new WalkBank(bot);
        isbankopennewtask = new IsBankOpenNewTask(bot);
    }

    private Area bankArea = new Area.Rectangular( new Coordinate(2885,3538,0), new Coordinate(2893, 3534, 0));

    @Override
    public boolean validate() {

        return Bot.player !=null && bankArea.contains(Bot.player) || new Area.Circular(new Coordinate(3449, 3717, 0), 40).contains(Bot.player);
    }

    @Override
    public TreeTask failureTask() {
        return walkbank;
    }

    @Override
    public TreeTask successTask() {
        return isbankopennewtask;
    }
}
