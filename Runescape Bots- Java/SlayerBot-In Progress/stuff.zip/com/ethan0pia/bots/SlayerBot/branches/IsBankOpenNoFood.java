package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.BranchTask;
import com.runemate.game.api.script.framework.tree.TreeTask;

import path.to.your.WithdrawFood
import path.to.your.OpenBank

/**
 * NOTES:
 * Checks if the bank is open when player does not have food.
 */
public class IsBankOpenNoFood extends BranchTask {

    private WithdrawFood withdrawfood;
    private OpenBank openbank;
    private GoodAssSlayerBot Bot;

    public IsBankOpenNewTask(GoodAssSlayerBot bot){
        Bot=bot;
        withdrawfood = new WithdrawFood(bot;
        openbank = new OpenBank(bot;
    }

    @Override
    public boolean validate() {
        return Bank.isOpen();
    }

    @Override
    public TreeTask failureTask() {
        return openbank;
    }

    @Override
    public TreeTask successTask() {
        return withdrawfood;
    }
}
