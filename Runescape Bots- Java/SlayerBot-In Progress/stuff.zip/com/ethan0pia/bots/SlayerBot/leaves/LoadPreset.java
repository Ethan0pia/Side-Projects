package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.LeafTask;

/**
 * NOTES:
 * Loads the correct preset.
 */
public class LoadPreset extends LeafTask {

    @Override
    public void execute() {

    }
}
