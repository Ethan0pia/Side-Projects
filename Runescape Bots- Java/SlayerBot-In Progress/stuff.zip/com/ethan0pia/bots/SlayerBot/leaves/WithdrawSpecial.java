package please.add.your.pkg;

import com.runemate.game.api.script.framework.tree.LeafTask;

/**
 * NOTES:
 * Withdraw the special item
 */
public class WithdrawSpecial extends LeafTask {

    @Override
    public void execute() {

    }
}
