package com.ethan0pia.bots.SlayerBot.leaves;


import com.runemate.game.api.script.framework.tree.LeafTask;

public class EmptyLeaf extends LeafTask {

    @Override
    public void execute() {

    }
}